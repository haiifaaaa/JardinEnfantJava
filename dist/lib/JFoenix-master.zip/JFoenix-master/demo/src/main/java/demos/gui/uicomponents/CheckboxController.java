package demos.gui.uicomponents;

import io.datafx.controller.ViewController;

@ViewController(value = "/fxml/ui/Checkbox.fxml", title = "Material Design Example")
public class CheckboxController {

}
